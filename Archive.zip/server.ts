import { startServer } from "./app";


startServer();
