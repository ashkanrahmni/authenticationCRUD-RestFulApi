import express from "express";
import bodyParser from "body-parser";
import session from "express-session";
import cookieParser from "cookie-parser";
import authRoutes from "./src/modules/auth/auth.routes";
import homeRoutes from "./src/modules/home/home.routes";
import { connectMongo } from "./src/db/mongo";
import { connectRedis } from "./src/db/redis";
import { engine } from 'express-handlebars';
import dotenv from "dotenv";
import flash from 'express-flash';
import { errorHandler } from "./src/utils/errorHandler";
import path from "path";

const app = express();
dotenv.config();

app.use(errorHandler)
app.use(flash())
app.use(cookieParser())
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}))
app.use(
  session({
    secret: process.env.SESSION_SECRET!,
    resave: false,
    saveUninitialized: false,
  })
);
app.engine('handlebars', engine({
    defaultLayout: 'main',  
    
    layoutsDir: path.join(__dirname, 'src/views/layouts'),
    partialsDir:path.join(__dirname, 'src/views/partials')
  }));

  app.set('view engine', 'handlebars');
  app.set('views', path.join(__dirname, 'src/views')); 
  
app.use(express.static(path.join(__dirname, 'src/public')));

app.use("/auth", authRoutes);

app.use("/home", homeRoutes);

export const startServer = async () => {
  await connectMongo();
  await connectRedis();
 
  app.listen(3000, () => console.log("Server running on port 3000"));
};
