import Joi from "joi";

export const registerValidation = Joi.object({
    username: Joi.string().required().messages({
      "string.empty": "نام کاربری نمی‌تواند خالی باشد",
      "any.required": "وارد کردن نام کاربری الزامی است",
    }),
    email: Joi.string().email().required().messages({
      "string.email": "فرمت ایمیل صحیح نیست",
      "string.empty": "ایمیل نمی‌تواند خالی باشد",
      "any.required": "وارد کردن ایمیل الزامی است",
    }),
    password: Joi.string().min(6).required().messages({
      "string.empty": "رمز عبور نمی‌تواند خالی باشد",
      "string.min": "رمز عبور باید حداقل {#limit} کاراکتر باشد",
      "any.required": "وارد کردن رمز عبور الزامی است",
    }),
  });

export const loginValidation = Joi.object({
  username: Joi.string().required().messages({
        "string.empty": "نام کاربری نمی‌تواند خالی باشد",
        "any.required": "وارد کردن نام کاربری الزامی است",
  }),
  password: Joi.string().min(6).required().messages({
    "string.empty": "رمز عبور نمی‌تواند خالی باشد",
    "string.min": "رمز عبور باید حداقل {#limit} کاراکتر باشد",
    "any.required": "وارد کردن رمز عبور الزامی است",
  }),
});
