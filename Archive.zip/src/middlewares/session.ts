import { Request, Response, NextFunction } from "express";
import { redisClient } from "../db/redis";

export const sessionMiddleware = async (req: Request, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "ابتدا احراز کنید" });

  try {
    const session = await redisClient.get(`session:${token}`);
    if (!session) return res.status(401).json({ error: "شناسه شما منقضی شد" });

    next();
  } catch (error) {
    res.status(500).json({ error: "شناسه مورد تایید نیست" });
  }
};
