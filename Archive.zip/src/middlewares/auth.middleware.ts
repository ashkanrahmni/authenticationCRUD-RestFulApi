import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}
const key  = "1234567890"
const authenticateToken = (req: Request, res: Response, next: NextFunction): void => {
  const token = req.cookies.token || req.header('Authorization')?.replace('Bearer ', '');
  
  if (!token) {
    return next(new Error('Authorization token is required')); // Use next() for error handling
  }

  jwt.verify(token, key, (err: any, decoded: any) => {
    if (err) {
      console.log(err)
      //return next(new Error('Invalid or expired token')); 
    }

    req.user = decoded; // User Object  Is Ready
    next(); 
  });
};

export default authenticateToken;
