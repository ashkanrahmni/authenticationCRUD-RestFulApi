import { NextFunction, Request, Response } from "express";
import { registerUser, authenticateUser } from "./home.service";

export const HomeIndex = async (req: Request, res: Response,next:NextFunction):Promise<void> => {
  try {
    const current = req.user
    return res.render('home/index',{
      title:'welcome to auth service',
      layout:'dashboard',
      message:'Welcome',
      user:current
    })
  } catch (error:any) {
    res.status(400).json({ error: error.message });
    next(error)
  }
};

export const LoginIndex = async (req: Request, res: Response,next:NextFunction) => {
  try {
    return res.render('loginPage/index',{
      title:'ورود',
      message:'خوش آمدید'
    })
  } catch (error:any) {
    res.status(400).json({ error: error.message });
    next(error)
  }
};

export const RegisterIndex = async (req: Request, res: Response,next:NextFunction) => {
  try {
    return res.render('registerPage/index',{
      title:'ورود',
      message:req.flash()
    })
  } catch (error:any) {
    res.status(400).json({ error: error.message });
    next(error)
  }
};

