import { Router } from "express";
import { HomeIndex} from "./home.controller";
import authenticateToken from "../../middlewares/auth.middleware";

const router = Router();

router.get("/",authenticateToken,HomeIndex);


export default router;
