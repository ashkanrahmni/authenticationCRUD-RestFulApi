import { redisClient } from "../../db/redis";
import { Db } from "../../db/mongo";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { User } from "../../models/user.model";
import { registerValidation } from "../../utils/validations";

export const registerUser = async (
  userData: Omit<User, "_id">
): Promise<User> => {
  // Body Validator
  const { error } = registerValidation.validate(userData);
  if (error) {
    throw new Error(error.details[0].message);
  }


  // Validator Email And Username Checker
  const existingUser = await Db.collection("users").findOne({
    $or: [{ username: userData.username }, { email: userData.email }],
  });
  // 
  if (existingUser) {
    throw new Error(
      "ایمیل یا نام کاربری قبلا ثبت شده"
    );
  }

  // Password Hashed
  const hashedPassword = await bcrypt.hash(userData.password, 10);

  //  Create New Record 
  const result = await Db.collection("users").insertOne({
    ...userData,
    password: hashedPassword,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  if (!result.insertedId) {
    throw new Error("خطا در درون ریزی کاربر");
  }

  //  Find Registered User
  const user = await Db.collection("users").findOne({ _id: result.insertedId });
  if (!user) {
    throw new Error("ایجاد کاربر با مشکل مواجه شده");
  }

  return user as User;
};

export const authenticateUser = async (userData: { username: string; password: string }) => {
  const { username, password } = userData;

  const user = await Db.collection("users").findOne({ username });
  if (!user) throw new Error("کاربر وجود ندارد");

  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) throw new Error("رمز عبور را برسی کنید");

  const token = jwt.sign({ id: user._id, username }, process.env.JWT_SECRET!, {
    expiresIn: "12d",
  });

  await redisClient.set(`ssId:${user._id}`, token, { EX: 3600 });

  return token;
};
