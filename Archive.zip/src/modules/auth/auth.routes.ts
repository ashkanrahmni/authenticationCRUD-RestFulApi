import { Router } from "express";
import { register, login, LoginIndex, RegisterIndex } from "./auth.controller";

const router = Router();

router.get("/register", RegisterIndex);

router.post("/register", register);

router.get("/login", LoginIndex);

router.post("/login", login);

export default router;
