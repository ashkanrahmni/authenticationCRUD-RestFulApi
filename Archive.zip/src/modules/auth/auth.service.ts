import { redisClient } from "../../db/redis";
import { Db } from "../../db/mongo";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { User } from "../../models/user.model";
import { registerValidation } from "../../utils/validations";
export const registerUser = async (
  userData: Omit<User, "_id">, 
  req: any, 
  res: any
): Promise<User> => {
  // Body Validator
  const { error } = registerValidation.validate(userData);
  if (error) {
    req.flash('error', error.details[0].message);  
    return res.render('registerPage/index',{
      messages:req.flash()
    }); 
  }


  const existingUser = await Db.collection("users").findOne({
    $or: [{ username: userData.username }, { email: userData.email }],
  });

  if (existingUser) {
    const errorMessage = "ایمیل یا نام کاربری قبلا ثبت شده";
    req.flash('error', errorMessage); 
    return res.render('registerPage/index',{
      messages:req.flash()
    });  // Return immediately after redirect
  }

  // Password Hashed
  const hashedPassword = await bcrypt.hash(userData.password, 10);

  // Create New Record 
  const result = await Db.collection("users").insertOne({
    ...userData,
    password: hashedPassword,
    createdAt: new Date(),
    updatedAt: new Date(),
  });

  if (!result.insertedId) {
    const errorMessage = "خطا در درون ریزی کاربر";
    req.flash('error', errorMessage); 
    return res.render('registerPage/index',{
      messages:req.flash()
    });  // Return immediately after redirect
  }

  // Find Registered User
  const user = await Db.collection("users").findOne({ _id: result.insertedId });
  if (!user) {
    const errorMessage = "ایجاد کاربر با مشکل مواجه شده";
    req.flash('error', errorMessage);  
    return res.render('registerPage/index',{
      messages:req.flash()
    });  // Return immediately after redirect
  }

  return user as User;
};

  export const authenticateUser = async (userData: { username: string; password: string }, req: any,res:any) => {
    const { username, password } = userData;
  
    try {
      const user = await Db.collection("users").findOne({ username });
      if (!user) {
        req.flash('error', 'کاربر وجود ندارد'); 
        throw new Error("کاربر وجود ندارد");
      }
  
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        req.flash('error', 'رمز عبور را برسی کنید');
        throw new Error("رمز عبور را برسی کنید");
      }
  
      const token = jwt.sign({ id: user._id, username }, process.env.JWT_SECRET!, {
        expiresIn: "12d",
      });
        
      await redisClient.set(`session:${user._id}`, token, { EX: 3600 });
      res.redirect('/home');

  
    } catch (error) {
      throw error;
    }
  };
  