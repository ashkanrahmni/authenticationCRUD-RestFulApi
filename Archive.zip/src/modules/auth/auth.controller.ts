import { NextFunction, Request, Response } from "express";
import { registerUser, authenticateUser } from "./auth.service";

export const register = async (req: Request, res: Response) => {
  try {
    await registerUser(req.body,req,res);
  } catch (error:any) {
    return res.render('registerPage/index', { messages: req.flash() });
  }
};

export const login = async (req: Request, res: Response) => {
  try {
    await authenticateUser(req.body,req,res);
  } catch (error:any) {
    return res.render('loginPage/index', { messages: req.flash() });
  }
};

export const LoginIndex = async (req: Request, res: Response,next:NextFunction) => {
    try {
      return res.render('loginPage/index',{
        title:'ورود',
        message:req.flash()
      })
    } catch (error:any) {
      res.status(400).json({ error: error.message });
      next(error)
    }
  };
  
  export const RegisterIndex = async (req: Request, res: Response,next:NextFunction) => {
    try {
      return res.render('registerPage/index',{
        title:'ورود',
        message:req.flash()
      })
    } catch (error:any) {
      res.status(400).json({ error: error.message });
      next(error)
    }
  };
  
  
